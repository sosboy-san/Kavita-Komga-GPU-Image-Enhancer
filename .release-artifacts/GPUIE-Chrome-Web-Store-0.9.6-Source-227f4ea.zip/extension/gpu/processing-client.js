(()=>{'use strict';if(globalThis.__KKGR_PROCESSING__)return;
 const pending=new Map(),failures=new Map(),mainControllers=new Set();let generation=0;const sources=new WeakMap();let sourceCounter=0;let serial=Promise.resolve(),session=null,counter=0,connecting=null,lastPhase=null;
 const fail=(code,message,extra={})=>Object.assign(new Error(message),{code,...extra});
 const resourceFailure=code=>['MEMORY_BUDGET_EXCEEDED','ALLOCATION_FAILED','FRAMEBUFFER_INCOMPLETE','SIZE_LIMIT'].includes(code);
 const resourceMessage=()=>globalThis.__KKGR_I18N__?.t('processing.memory')||'Image processing memory or GPU size limit exceeded. Original image retained.';
 const close=()=>{if(session){session.postMessage({type:'STOP'});session.close();session=null;}};
 const cancelAll=()=>{generation++;for(const controller of mainControllers)controller.abort();globalThis.__KKGR_MAIN_PROCESSING__?.invalidate();close();for(const p of pending.values()){clearTimeout(p.timer);p.reject(fail('ANALYSIS_CANCELLED','Job cancelled'));}pending.clear();};
 function connect(){if(session)return Promise.resolve(session);if(connecting)return connecting;
  connecting=new Promise((resolve,reject)=>{const channel=new MessageChannel(),request='processing-'+(++counter),timer=setTimeout(()=>{channel.port1.close();reject(fail('WORKER_UNAVAILABLE','Processing worker unavailable'));},5000);
   channel.port1.onmessage=e=>{if(e.data?.type==='CONNECTED'){clearTimeout(timer);session=channel.port1;session.onmessage=onMessage;resolve(session);}else if(e.data?.error){clearTimeout(timer);reject(fail(e.data.error.code,e.data.error.message));}};channel.port1.start();
   window.postMessage({channel:'kkgr-processing-connect',request,session:globalThis.__KKGR_PLATFORM__?.processingSession?.()},location.origin,[channel.port2]);
  }).finally(()=>{connecting=null;});return connecting;
 }
 function onMessage(e){const m=e.data;if(m.error&&!m.id){for(const p of pending.values()){clearTimeout(p.timer);p.reject(fail(m.error.code,m.error.message));}pending.clear();close();return;}const p=pending.get(m.id);if(!p)return;if(m.type==='DIAGNOSTIC'){globalThis.__KKGR_DIAGNOSTICS__?.event(p.token,m.event);return;}if(m.type==='PHASE'){globalThis.__KKGR_DIAGNOSTICS__?.event(p.token,{stage:m.stage,module:m.module,parameters:p.parameters?.[m.stage],action:m.action});p.phase={stage:m.stage,module:m.module,action:m.action};lastPhase=p.phase;if(m.stage==='encode'){clearTimeout(p.timer);p.timer=setTimeout(()=>{pending.delete(m.id);close();p.reject(fail('ENCODE_TIMEOUT','Image encoding exceeded 30 seconds'));},30000);}return;}
  clearTimeout(p.timer);pending.delete(m.id);if(m.error){const timeout=['PROCESSING_TIMEOUT','ANALYSIS_TIMEOUT','GPU_TIMEOUT'].includes(m.error.code),stage=p.phase?.stage||'renderer',name=p.phase?.module?.name||p.provider,I=globalThis.__KKGR_I18N__;const message=timeout?(I?I.t('processing.timeout',{name,stage:I.t(stage==='pre'?'filter.pre':stage==='post'?'filter.post':'renderer.title'),seconds:p.timeoutMs/1000}):name+' ('+stage+') exceeded '+(p.timeoutMs/1000)+' seconds'):resourceFailure(m.error.code)?resourceMessage():m.error.message;const err=fail(m.error.code,message,{...(p.phase||{}),timeoutMs:p.timeoutMs});if(resourceFailure(err.code)||['PROCESSING_TIMEOUT','ANALYSIS_TIMEOUT','GPU_TIMEOUT'].includes(err.code)){failures.set(p.key,err);while(failures.size>128)failures.delete(failures.keys().next().value);}p.reject(err);}
  else if(m.type==='RESULT')p.resolve(m);
 }
 async function execute(provider,source,sw,sh,dw,dh,type,settings,_reserved=false,jobGeneration=generation,context={}){
  const D=globalThis.__KKGR_DIAGNOSTICS__,token=context.token,entered=performance.now();D?.event(token,{timings:{queueMs:entered-context.queuedAt}});try{
  if(jobGeneration!==generation)throw fail('ANALYSIS_CANCELLED','Job cancelled');
  const snapshot=JSON.parse(JSON.stringify(settings||{})),timeoutMs=snapshot.processingTimeoutMs||10000,mode=snapshot.processingMode==='speed'?'speed':'worker';
  const slots=snapshot.filters||{},useRenderer=provider!=='browser'&&(sw!==dw||sh!==dh),builtin={lohalo:'lohalo-jr',nohalo:'nohalo-jr'};
  const plan={pre:slots.pre||null,renderer:useRenderer?(builtin[provider]||provider):null,post:slots.post||null};
  const packages=[...new Set([plan.pre,plan.renderer,plan.post].filter(Boolean))].map(id=>globalThis.__KKGR_PACKAGE_SOURCES__?.[id]).filter(Boolean);
  let runtime=globalThis.__KKGR_MODULE_RUNTIME__;
  if(runtime&&!runtime.ready&&!runtime.errors?.length&&globalThis.__KKGR_PLATFORM__?.ensureModuleRuntime){
   await globalThis.__KKGR_PLATFORM__.ensureModuleRuntime();runtime=globalThis.__KKGR_MODULE_RUNTIME__;
   if(jobGeneration!==generation||(runtime&&!runtime.ready&&!runtime.errors?.length))throw fail('ANALYSIS_CANCELLED','Module preparation pending');
  }
  // Reader Core selects the provider before the asynchronous settings echo arrives.
  // Validate the renderer this job executes, rather than the settings mirror.
  // An omitted optional filter slot and an explicit null both mean OFF.
  const selected=runtime?.slots,selectionChanged=selected&&(provider!==selected.renderer||(slots.pre||null)!==(selected.pre||null)||(slots.post||null)!==(selected.post||null));
  if(runtime&&(runtime.mode!==mode||selectionChanged))throw fail('ANALYSIS_CANCELLED','Module selection changed');
  if(runtime&&!runtime.ready)throw fail('MODULE_RUNTIME_UNAVAILABLE',runtime.errors?.[0]?.message||'Module runtime is not ready');
  if(packages.length&&!runtime)throw fail('MODULE_RUNTIME_UNAVAILABLE','Module selection is not initialized');
  if(runtime?.needsUserScripts){
   const authorize=globalThis.__KKGR_PLATFORM__?.authorizeModules;if(!authorize)throw fail('MODULE_ACCESS_REVOKED','Module authorization bridge unavailable');
   try{const result=await authorize({runtimeKey:runtime.key,mode,packages:packages.map(p=>({id:p.id,stamp:p.stamp}))});if(!result?.ok)throw Error('Module access revoked');}
   catch(e){if(globalThis.__KKGR_MODULE_RUNTIME__!==runtime||(jobGeneration!==generation&&runtime.ready))throw fail('ANALYSIS_CANCELLED','Module runtime changed');if(jobGeneration===generation)cancelAll();throw fail('MODULE_ACCESS_REVOKED',String(e.message));}
   if(globalThis.__KKGR_MODULE_RUNTIME__!==runtime||!runtime.ready)throw fail('ANALYSIS_CANCELLED','Module runtime changed');
  }
  for(const id of [plan.pre,plan.post])if(id&&!globalThis.__KKGR_BUILTIN_FILTER_MODULES__?.[id]&&!packages.some(p=>p.id===id))throw fail('INVALID_DESCRIPTOR','Filter source unavailable: '+id);
  if(!sources.has(source))sources.set(source,++sourceCounter);
  const key=JSON.stringify([mode,provider,source?.currentSrc||source?.src||sources.get(source),sw,sh,dw,dh,type,type==='image/jpeg'?0.9:1,plan,snapshot.filterParameters,packages.map(p=>[p.id,p.stamp]),timeoutMs,snapshot.processingRetryRevision||0]);
  if(context.bypassAnalysisStage)failures.delete(key);if(failures.has(key)){D?.event(token,{outcome:'retry-suppressed'});throw failures.get(key);}
  const epoch=globalThis.__KKGR_CORE__?.processingEpoch,sourceUrl=source?.currentSrc||source?.src;
  const current=()=>sourceUrl===(source?.currentSrc||source?.src)&&jobGeneration===generation&&(epoch===undefined||epoch===globalThis.__KKGR_CORE__?.processingEpoch)&&(!context.isCurrent||context.isCurrent());
  if(!current())throw fail('ANALYSIS_CANCELLED','Job cancelled');
  if(mode==='speed'){
   if(!globalThis.__KKGR_MAIN_PROCESSING__)throw fail('EXECUTOR_UNAVAILABLE','Reader-thread executor unavailable');
   const parameters=globalThis.__KKGR_PARAMETERS__?.selected(snapshot,snapshot.filterCatalog||[])||{};
   const phase=(stage,d,action)=>{const module=d?{id:d.id,packageId:d.packageId||d.id,name:d.name,version:d.version,implementationRevision:d.implementationRevision,stamp:d.stamp||null}:null;lastPhase={stage,module,action};D?.event(token,{stage,module,action,parameters:parameters[stage]});};
   const controller=new AbortController();mainControllers.add(controller);lastPhase=null;let result;try{result=await globalThis.__KKGR_MAIN_PROCESSING__.run({source,sw,sh,dw,dh,plan,packages,parameters,timeoutMs,settingsRevision:epoch??snapshot.revision??0,mimeType:type,bypassAnalysisStage:context.bypassAnalysisStage},{signal:controller.signal,isCurrent:current,phase,report:token?event=>D?.event(token,event):null});}catch(e){if(resourceFailure(e.code)||['PROCESSING_TIMEOUT','ANALYSIS_TIMEOUT','GPU_TIMEOUT'].includes(e.code)){Object.assign(e,lastPhase,{timeoutMs});const I=globalThis.__KKGR_I18N__,stage=e.stage||'renderer',name=e.module?.name||provider;if(resourceFailure(e.code))e.message=resourceMessage();else if(I)e.message=I.t('processing.timeout',{name,stage:I.t(stage==='pre'?'filter.pre':stage==='post'?'filter.post':'renderer.title'),seconds:timeoutMs/1000});failures.set(key,e);while(failures.size>128)failures.delete(failures.keys().next().value);}throw e;}finally{mainControllers.delete(controller);}
   if(!current())throw fail('ANALYSIS_CANCELLED','Job cancelled');D?.event(token,{encoding:result.encoding,timings:{...result.timings,processingTotalMs:performance.now()-context.queuedAt}});if(result.encoding?.fallback)globalThis.__KKGR_CORE__?.outputWarning?.();D?.finish(token,'succeeded',result);D?.bindBlob(result.blob,token,result.colorSuggestions);globalThis.__KKGR_GPU_LAST_JOB__=Object.freeze({id:provider,source:[sw,sh],output:result.outputSize,rendererUsed:useRenderer,trace:result.trace,format:result.format,computeAndWaitMs:result.elapsedMs,resources:result.resources,isolated:false});return result.blob;
  }
  const bitmapStarted=performance.now();let transferable;if(ArrayBuffer.isView(source))transferable=source.slice();else transferable=await createImageBitmap(source,{premultiplyAlpha:'none'});D?.event(token,{timings:{bitmapMs:performance.now()-bitmapStarted}});
  if(!current()||sourceUrl!==(source?.currentSrc||source?.src)){transferable?.close?.();throw fail('ANALYSIS_CANCELLED','Job cancelled');}
  const connectStarted=performance.now();let port;try{port=await connect();}catch(e){transferable?.close?.();throw e;}if(!current()){transferable?.close?.();close();throw fail('ANALYSIS_CANCELLED','Job cancelled');}D?.event(token,{timings:{connectMs:performance.now()-connectStarted}});const id=context.id,parameters=globalThis.__KKGR_PARAMETERS__?.selected(snapshot,snapshot.filterCatalog||[])||{};
  const roundTripStarted=performance.now();let result;result=await new Promise((resolve,reject)=>{const p={resolve,reject,key,phase:null,timeoutMs,provider,token,parameters};p.timer=setTimeout(()=>{const I=globalThis.__KKGR_I18N__,stage=p.phase?.stage||'renderer',name=p.phase?.module?.name||provider;const message=I?I.t('processing.timeout',{name,stage:I.t(stage==='pre'?'filter.pre':stage==='post'?'filter.post':'renderer.title'),seconds:timeoutMs/1000}):name+' ('+stage+') exceeded '+(timeoutMs/1000)+' seconds';const err=fail('PROCESSING_TIMEOUT',message,{...(p.phase||{}),timeoutMs});failures.set(key,err);while(failures.size>128)failures.delete(failures.keys().next().value);pending.delete(id);close();reject(err);},timeoutMs);pending.set(id,p);
   port.postMessage({type:'RUN',id,diagnostics:!!token,bypassAnalysisStage:['pre','post'].includes(context.bypassAnalysisStage)?context.bypassAnalysisStage:null,source:transferable,sw,sh,dw,dh,mimeType:type,encodeQuality:type==='image/jpeg'?0.9:1,plan,packages,parameters,timeoutMs,settingsRevision:epoch??snapshot.revision??0},transferable instanceof ImageBitmap?[transferable]:[]);
  });const roundTripMs=performance.now()-roundTripStarted;D?.event(token,{timings:{...result.timings,roundTripMs,bridgeAndSchedulingMs:Math.max(0,roundTripMs-result.elapsedMs-(result.timings?.workerQueueMs||0)),processingTotalMs:performance.now()-context.queuedAt}});if(!current()){D?.event(token,{outcome:'discarded'});throw fail('ANALYSIS_CANCELLED','Job cancelled');}if(result.encoding?.fallback)globalThis.__KKGR_CORE__?.outputWarning?.();D?.event(token,{encoding:result.encoding});D?.finish(token,'succeeded',result);D?.bindBlob(result.blob,token,result.colorSuggestions);
  globalThis.__KKGR_GPU_LAST_JOB__=Object.freeze({id:provider,source:[sw,sh],output:[useRenderer?dw:sw,useRenderer?dh:sh],rendererUsed:useRenderer,trace:result.trace,format:result.format,computeAndWaitMs:result.elapsedMs,resources:result.resources,isolated:true});return result.blob;
  }catch(e){D?.event(token,{timings:{processingTotalMs:performance.now()-context.queuedAt}});D?.finish(token,e.code==='ANALYSIS_CANCELLED'?'cancelled':'failed',null,e);throw e;}
 }
 const start=(...args)=>{const jobGeneration=generation,context={...(args[9]||{}),queuedAt:performance.now(),id:'job-'+(++counter)};args.length=9;args[7]=JSON.parse(JSON.stringify(args[7]||{}));args[8]=!!args[8];context.token=globalThis.__KKGR_DIAGNOSTICS__?.begin(context.id,args[1]?.currentSrc||args[1]?.src||args[1],[args[2],args[3]],[args[4],args[5]],args[7],context.role);globalThis.__KKGR_DIAGNOSTICS__?.sourceTiming(context.token,args[1]);globalThis.__KKGR_DIAGNOSTICS__?.event(context.token,{mimeType:args[6]});const job=serial.catch(()=>{}).then(()=>execute(...args,jobGeneration,context));serial=job;return job;};
 globalThis.__KKGR_PROCESSING__=Object.freeze({moduleRuntimeVersion:5,start,cancelAll,retry(){failures.clear();cancelAll();},diagnostics:()=>({failures:failures.size,phase:lastPhase})});
 globalThis.addEventListener?.('pagehide',cancelAll);
})();
